
package bookstore.st10288567;
// Importing the JOptionPane class for GUI dialogs
import javax.swing.JOptionPane;

public class BOOKSTOREST10288567 {

  // Main method - entry point of the program
    public static void main(String[] args) {
            
        // Initialize an array of book titles
        String[] books = {
            "Harry Potter",
            "The Great Gatsby",
            "To Kill a Mockingbird",
            "Pride and Prejudice",
            "Othello"
        };

        // Options for sorting order
        String[] options = {"Ascending", "Descending"};
        // Display a dialog to the user to choose the sort order
        int choice = JOptionPane.showOptionDialog(
            null,
            "Would you like to sort the books in ascending or descending order?",
            "Sort Order",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]
        );

        // Check the user's choice and sort the array accordingly
        if (choice == 0) {
            // If the user chose ascending order, call the insertionSortAscending method
            insertionSortAscending(books);
            // Display the sorted array in ascending order
            JOptionPane.showMessageDialog(null, "Books sorted in ascending order: " + String.join(", ", books));
        } else if (choice == 1) {
            // If the user chose descending order, call the insertionSortDescending method
            insertionSortDescending(books);
            // Display the sorted array in descending order
            JOptionPane.showMessageDialog(null, "Books sorted in descending order: " + String.join(", ", books));
        } else {
            // If no valid choice was made, display a message
            JOptionPane.showMessageDialog(null, "No sort order selected.");
        }
    }

    // Method to sort the array in ascending order using insertion sort algorithm
    public static void insertionSortAscending(String[] array) {
        // Iterate over each element starting from the second element
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // Store the current element in key
            int j = i - 1;
            // Move elements of array[0..i-1], that are greater than key, to one position ahead of their current position
            while (j >= 0 && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j]; // Shift element to the right
                j = j - 1;
            }
            array[j + 1] = key; // Place key at its correct position
        }
    }

    // Method to sort the array in descending order using insertion sort algorithm
    public static void insertionSortDescending(String[] array) {
        // Iterate over each element starting from the second element
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // Store the current element in key
            int j = i - 1;
            // Move elements of array[0..i-1], that are less than key, to one position ahead of their current position
            while (j >= 0 && array[j].compareTo(key) < 0) {
                array[j + 1] = array[j]; // Shift element to the right
                j = j - 1;
            }
            array[j + 1] = key; // Place key at its correct position
        }
    }
}
